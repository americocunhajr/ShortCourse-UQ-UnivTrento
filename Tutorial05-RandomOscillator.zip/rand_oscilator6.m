figure(1)
fh1 = plot(t,Qd_smean,'b','linewidth',3); hold on
fh2 = plot(t,Qd_std,'r','linewidth',3);
fh3 = fill([t' fliplr(t')],[Qd_upp fliplr(Qd_low)],'y');
uistack(fh3,'top');
uistack(fh2,'top');
uistack(fh1,'top');
legend('envelope','std','mean')
hold off

figure(2)
fh1 = plot(t,Qv_smean,'b','linewidth',3); hold on
fh2 = plot(t,Qv_std,'r','linewidth',3);
fh3 = fill([t' fliplr(t')],[Qv_upp fliplr(Qv_low)],'y');
uistack(fh3,'top');
uistack(fh2,'top');
uistack(fh1,'top');
legend('envelope','std','mean')
hold off