figure(3)
bar(Qd_bins,Qd_freq,1.0);
hold on
plot(Qd_supp,Qd_ksd,'r','linewidth',3)
hold off

figure(4)
bar(Qv_bins,Qv_freq,1.0);
hold on
plot(Qv_supp,Qv_ksd,'r','linewidth',3)
hold off