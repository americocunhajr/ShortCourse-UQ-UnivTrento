function [data_ksd,data_supp] = randvar_ksd(data,numpts)
        
data_max = max(data);
data_min = min(data);
data_pts = linspace(data_min,data_max,numpts);
    
[data_ksd,data_supp] = ksdensity(data,data_pts);

return