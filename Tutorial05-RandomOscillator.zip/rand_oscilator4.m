% sample mean
Qd_smean = mean(Qd');
Qv_smean = mean(Qv');

% temporal mean
Qd_tmean = mean(Qd);
Qv_tmean = mean(Qv);

% std. dev.
Qd_std  = std(Qd');
Qv_std  = std(Qv');

% confidence band
Pc = 95; 
r_plus = 0.5*(100 + Pc); r_minus = 0.5*(100 - Pc);
Qd_upp = prctile(Qd',r_plus);
Qv_upp = prctile(Qv',r_plus);
Qd_low = prctile(Qd',r_minus);
Qv_low = prctile(Qv',r_minus);