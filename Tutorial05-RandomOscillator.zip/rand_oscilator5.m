% histogram of temporal mean
Nbins = round(sqrt(Ns));
[Qd_bins,Qd_freq] = randvar_pdf(Qd_tmean,Nbins);
[Qv_bins,Qv_freq] = randvar_pdf(Qv_tmean,Nbins);

% kernel density estimator for temporal mean
[Qd_ksd,Qd_supp] = ksdensity(Qd_tmean);
[Qv_ksd,Qv_supp] = ksdensity(Qv_tmean);