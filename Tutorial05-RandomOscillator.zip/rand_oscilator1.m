clc
clear all
close all

t0  = 0.0;   % initial time of analysis (s)
t1  = 30.0;  % final time of analysis (s)
Ndt = 300;   % number of time steps

m  = 1.0;    % system mass (kg)
c  = 0.1;    % damper constant (N.s/m)
k  = 5.0;    % stiffness constant (N/m)
x0 = 1.0;    % initial position (m)
v0 = 1.0;    % initial velocity (m/s)