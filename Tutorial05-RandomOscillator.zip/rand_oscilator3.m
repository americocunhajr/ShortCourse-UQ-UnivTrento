% init. cond. and interval of analysis
IC = [x0 v0]; tspam = linspace(t0,t1,Ndt);

% Monte Carlo method
for n=1:Ns

    % system of equations
    dydt=@(t,y)[0 1; -k(n) -c]*y;
    
    % ODE solver Runge-Kutta45
    [t,y] = ode45(dydt,tspam,IC);
    
    % time series of system displacement (m)
    Qd(:,n) = y(:,1);
    
    % time series of system velocity (m/s)
    Qv(:,n) = y(:,2);
end