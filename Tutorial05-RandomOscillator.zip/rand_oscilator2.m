% define stochastic parameters
rng_stream = RandStream('mt19937ar','Seed',30081984);
RandStream.setGlobalStream(rng_stream);

% number of samples
Ns = 256;
% preallocate memory for displacement and velocity
Qd = zeros(Ndt,Ns);
Qv = zeros(Ndt,Ns);
% stiffness mean (N/m)
mean_k = k;
% stiffness coef. var
coefvar_k = 0.15;
% generate stiffness with Gamma distribution (N/m)
k = gamrnd(1/coefvar_k^2,mean_k*coefvar_k^2,[Ns,1]);