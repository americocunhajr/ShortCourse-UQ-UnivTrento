clc; clear; close all;

Ns = 50; Pc = 95;

A = rand(Ns,1); x = 0:0.01:30; Y = A*sin(x);
r_plus  = 0.5*(100 + Pc); r_minus = 0.5*(100 - Pc);
Y_upp = prctile(Y,r_plus); Y_low = prctile(Y,r_minus);

figure(1)
fh1 = plot(x,mean(Y),'r','linewidth',3);
hold on
fh2 = plot(x,Y(1:10,:),'--b','linewidth',0.5);
fh3 = fill([x fliplr(x)],[Y_upp fliplr(Y_low)],'y');
uistack(fh3,'top');
uistack(fh1,'top');
uistack(fh2,'top');
legend('envelope','mean','samples')
hold off