clc; clear; close all;
m = 1.0; ksi = 0.1; wn = 4.0; f = 10.0; w = 5.0;
x0 = 1.0; v0 = 0.0; t0 = 0.0; t1 = 50.0; N = 5000;

dphidt=@(t,phi)[0 1; -wn^2 -2*ksi*wn]*phi ...
             + [0; (f/m)*sin(w*t)];

[t_ref,phi_ref] = euler3(dphidt,[x0;v0],t0,t1,N);

t_exp1 = t_ref(1:20:end);
x_exp1 = phi_ref(1,1:20:end) + 0.05*randn;
t_exp2 = t_ref(1:50:end);
x_exp2 = phi_ref(1,1:50:end) + 0.1*randn;

figure(1)
plot(t_exp1,x_exp1,'xr','LineWidth',3);
hold on
plot(t_exp1,x_exp1,'--r','LineWidth',0.3);
hold off
axis([t0 t1 -2 2])
set(gca,'fontsize',18)
legend('Experiment 1')

figure(2)
plot(t_exp2,x_exp2,'ok','LineWidth',3);
hold on
plot(t_exp2,x_exp2,'--k','LineWidth',0.3);
hold off
axis([t0 t1 -2 2])
set(gca,'fontsize',18)
legend('Experiment 2')

m = 1.0; ksi = 0.05; wn = 3.2; f = 10.0; w = 5.0;
x0 = 1.0; v0 = 0.0;

dphidt=@(t,phi)[0 1; -wn^2 -2*ksi*wn]*phi ...
             + [0; (f/m)*sin(w*t)];

[t_uncal,phi_uncal] = euler3(dphidt,[x0;v0],t0,t1,N);

figure(3)
plot(t_uncal,phi_uncal(1,:),'b','LineWidth',3);
hold on
plot(t_exp1,x_exp1,'xr','LineWidth',3);
plot(t_exp1,x_exp1,'--r','LineWidth',0.3);
hold off
axis([t0 t1 -2 2])
set(gca,'fontsize',18)
legend('Uncalibrated','Experiment 1')

m = 1.0; ksi = 0.095; wn = 4.08; f = 10.0; w = 5.0;
x0 = 1.0; v0 = 0.0;

dphidt=@(t,phi)[0 1; -wn^2 -2*ksi*wn]*phi ...
             + [0; (f/m)*sin(w*t)];

[t_cal,phi_cal] = euler3(dphidt,[x0;v0],t0,t1,N);

figure(4)
plot(t_cal,phi_cal(1,:),'g',t_uncal,phi_uncal(1,:),'b','LineWidth',3);
hold on
plot(t_exp1,x_exp1,'xr','LineWidth',3);
plot(t_exp1,x_exp1,'--r','LineWidth',0.3);
hold off
axis([t0 t1 -2 2])
set(gca,'fontsize',18)
legend('Calibrated','Uncalibrated','Experiment 1')
      
figure(5)
plot(t_cal,phi_cal(1,:),'g','LineWidth',3);
hold on
plot(t_exp1,x_exp1,'xr','LineWidth',3);
plot(t_exp2,x_exp2,'ok','LineWidth',3);
plot(t_exp1,x_exp1,'--r','LineWidth',0.3);
plot(t_exp2,x_exp2,'--k','LineWidth',0.3);
hold off
axis([t0 t1 -2 2])
set(gca,'fontsize',18)
legend('Calibrated','Experiment 1','Experiment 2')
