clc; clear all; close all;
m = 1.0; ksi = 0.1; wn = 4.0; f = 0; w = 5.0;
x0 = 1.0; v0 = 0.0; t0 = 0.0; t1 = 10.0; N = 3000;

dphidt=@(t,phi)[0 1; -wn^2 -2*ksi*wn]*phi ...
             + [0; (f/m)*sin(w*t)];

[time,phi] = euler3(dphidt,[x0;v0],t0,t1,N);

wd     = wn*sqrt(1-ksi^2);
A      = sqrt(x0^2 + ((v0+ksi*wn*x0)/wd)^2);
theta  = atan((x0*wd)/(v0+ksi*wn*x0));
x_true = A*exp(-ksi*wn*time).*sin(wd*time+theta);

subplot(2,1,1) 
plot(time,phi(1,:),'b','LineWidth',3);
legend('Euler')
subplot(2,1,2) 
plot(time,x_true,  'g','LineWidth',3);
legend('True')