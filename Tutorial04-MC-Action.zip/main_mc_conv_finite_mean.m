clc; clear; close all

Ns = 10^3;
X1 = randn(Ns,1); X2 = randn(Ns,1); X3 = randn(Ns,1);
Y1 = 1./(1+X1.^2); Y2 = 1./(1+X2.^2); Y3 = 1./(1+X3.^2);

meanY1 = mean(Y1)
meanY2 = mean(Y2)
meanY3 = mean(Y3)

figure(1)
plot(1:Ns,X1,'xb',1:Ns,X2,'xg',1:Ns,X3,'xm','LineWidth',1)
set(gca,'fontsize',18)
xlabel('index'); ylabel('X'); xlim([1,Ns]); ylim([-4 4]);

figure(2)
plot(1:Ns,Y1,'xb',1:Ns,Y2,'xg',1:Ns,Y3,'xm','LineWidth',1)
hold on
plot([1 Ns],[meanY1 meanY1],'b-', 'LineWidth', 4);
plot([1 Ns],[meanY2 meanY2],'g-', 'LineWidth', 4);
plot([1 Ns],[meanY3 meanY3],'m-', 'LineWidth', 4);
hold off
xlabel('index'); ylabel('Y'); xlim([1,Ns]); ylim([0 1]);
