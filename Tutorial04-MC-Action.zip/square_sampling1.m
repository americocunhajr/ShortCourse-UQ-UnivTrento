clc; clear; close all;

Ns = 1000; xmin = 0.0; xmax = 1.0; ymin = 0.0; ymax = 1.0;

mu = 0.5; coefvar = 0.5; sigma = mu*coefvar;

% uniform sample
Xu = rand(Ns); Yu = rand(Ns);

% normal sample
Xn = mu + sigma*randn(Ns); Yn = mu + sigma*randn(Ns);

% gamma sample
Xg = gamrnd(1/coefvar^2,mu*coefvar^2,Ns);
Yg = gamrnd(1/coefvar^2,mu*coefvar^2,Ns);

% Chi-squared sample
Xc2 = chi2rnd(mu,Ns); Yc2 = chi2rnd(mu,Ns);