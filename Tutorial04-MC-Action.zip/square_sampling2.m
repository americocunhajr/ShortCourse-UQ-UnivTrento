figure(1)
plot(Xu,Yu,'.b');
axis([xmin xmax ymin ymax]);
title(' Uniform Distribution','FontSize',20)

figure(2)
plot(Xn,Yn,'.r');
axis([xmin xmax ymin ymax]);
title(' Normal Distribution','FontSize',20)

figure(3)
plot(Xg,Yg,'.g');
axis([xmin xmax ymin ymax]);
title(' Gamma Distribution','FontSize',20)

figure(4)
plot(Xc2,Yc2,'.m');
axis([xmin xmax ymin ymax]);
title(' Chi-squared Distribution','FontSize',20)